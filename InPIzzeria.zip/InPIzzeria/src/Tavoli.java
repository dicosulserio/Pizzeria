public class Tavoli implements Runnable {
    private int nTavolo;
    private int persone = 5;
    private String[] menu = {"Margherita", "Diavola", "Marinara", "Salamino"};
    private String[] pizze;
    BufferPizze buffer;

    public Tavoli(BufferPizze a, int nTavolo) {
        buffer = a;
        this.nTavolo = nTavolo;
    }

    public void run() {
        while (true) {
            pizze = new String[persone];

            for (int i = 0; i < persone; i++) {
                pizze[i] = menu[(int) (Math.random() * 4)];
            }

            Ordine ordine = new Ordine(pizze, nTavolo);
            System.out.println("Tavolo " + nTavolo + " ha fatto un ordine.");
            buffer.pushOrder(ordine);
        }
    }
}