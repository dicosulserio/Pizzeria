public class BufferPizze {
    private Ordine[] order;
    private int i = 0;

    public BufferPizze() {
        order = new Ordine[20]; // inizializzare l'array
    }

    public synchronized void pushOrder(Ordine ordine) {
        while (i >= order.length) {
            try {
                wait();
            } catch (InterruptedException e) {}
        }

        this.order[i] = ordine;
        i++;
        notifyAll();
    }

    public synchronized boolean isOrder() {
        return i > 0;
    }

    public synchronized Ordine getOrder() {
        while (i <= 0) {
            try {
                wait(); // attendi se il buffer è vuoto
            } catch (InterruptedException e) {}
        }

        Ordine daRimuovere = order[--i];
        order[i] = null;
        notifyAll();
        return daRimuovere;
    }
}