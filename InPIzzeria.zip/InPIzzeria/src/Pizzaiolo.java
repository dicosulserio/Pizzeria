public class Pizzaiolo implements Runnable {
    private BufferPizze LeggeCameriere;
    private BufferPizze ScriveCameriere;

    public Pizzaiolo(BufferPizze a, BufferPizze b) {
        LeggeCameriere = a;
        ScriveCameriere = b;
    }

    public void run() {
        while (true) {
            Ordine ordine = LeggeCameriere.getOrder();
            try {
                Thread.sleep(2500);
            } catch (InterruptedException e) {
            }

            ScriveCameriere.pushOrder(ordine);
        }
    }
}